<?php
	system("node ./ch.js");
?>