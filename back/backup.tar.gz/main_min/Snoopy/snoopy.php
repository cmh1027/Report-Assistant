<?php
//Snoopy.class.php를 불러옵니다
require($_SERVER['DOCUMENT_ROOT'].'/디렉토리/Snoopy.class.php');
 
//스누피를 생성해줍시다
$snoopy = new Snoopy;
 
//스누피의 fetch함수로 제 웹페이지를 긁어볼까요? :)
$snoopy->fetch('http://dovetail.tistory.com/38');
 
//결과는 $snoopy->results에 저장되어 있습니다
//preg_match 정규식을 사용해서 이제 본문인 article 요소만을 추출해보도록 하죠
preg_match('/<div class="article">(.*?)<\/div>/is', $snoopy->results, $text);
 
//이제 결과를 보면...?
echo $text[1];
?>