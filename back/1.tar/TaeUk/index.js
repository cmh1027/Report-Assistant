console.log('작동');
/*
$$(".navbar-brand")[0].onclick = test;

function test(){
	new Ajax.Request("index.php", {
		method: "post",
		parameters:{test:"TEST"},
		onSuccess: function(){
			console.log('Success');
			},
		onFailure: function(){console.log('FAIL');},
		onException: function(){console.log('Exception');}
	});
}

*/

//$("<p>hi</p>").appendTo('#window_login');

/*
$("#nb").click(function test(){
	$.ajax({
			url:'add.php', // 값을 전달할 php 파일
			type : "post", // post OR get 을 입력
			data : {b_login:false}, // 전달할 데이터
			success:function(data){ // 전달에 성공했을때 어떤 기능을 수행할지
				console.log('success');
				alert(data);
			}
	});
});
*/

/*
$('#nb').click(function() {
	$('nb').load('indx.php');
});
*/
/*
function test(){
	$.ajax({
			url:'index.php', // 값을 전달할 php 파일
			type : "post", // post OR get 을 입력
			data : {b_login:false}, // 전달할 데이터
			success:function(b_login){ // 전달에 성공했을때 어떤 기능을 수행할지
			console.log('success');
		}
	});
}
*/