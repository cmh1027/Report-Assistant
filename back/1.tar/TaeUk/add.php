<?php
$number1 = $_POST['number1'];
$number2 = $_POST['number2'];
$b_login = $_POST['b_login'];
//$result = $number1 + $number2;

echo "변수값은 $number1 $number2 $b_login 입니다";