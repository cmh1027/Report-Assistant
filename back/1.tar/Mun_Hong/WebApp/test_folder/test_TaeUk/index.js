console.log('작동');
$('.navbar-brand').click(function() {
	window.alert("작동확인");
});

$('#nb').click(function() {
	window.alert("작동확인");
	console.log('hi');
});