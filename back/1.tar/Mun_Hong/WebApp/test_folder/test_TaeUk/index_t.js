$('.navbar-brand').click(function() {
	
});
